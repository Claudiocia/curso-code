<div class="form-group">
    {!! Form::label('codigo', 'Código:') !!}
    {!! Form::text('code', null, ['class'=>'form-control']) !!}
</div>

<div class="form-group">
    {!! Form::label('valor', 'Valor:') !!}
    {!! Form::text('value', null, ['class'=>'form-control']) !!}
</div>