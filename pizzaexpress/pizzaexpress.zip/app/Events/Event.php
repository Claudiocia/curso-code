<?php

namespace pizzaexpress\Events;

abstract class Event
{
    //
}
