<?php

namespace pizzaexpress\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface OrderItemRepository
 * @package namespace pizzaexpress\Repositories;
 */
interface OrderItemRepository extends RepositoryInterface
{
    //
}
