<?php

namespace pizzaexpress\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ProductRepository
 * @package namespace pizzaexpress\Repositories;
 */
interface ProductRepository extends RepositoryInterface
{
    //
}
