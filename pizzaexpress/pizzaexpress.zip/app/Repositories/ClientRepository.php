<?php

namespace pizzaexpress\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ClientRepository
 * @package namespace pizzaexpress\Repositories;
 */
interface ClientRepository extends RepositoryInterface
{
    //
}
