<?php

namespace pizzaexpress\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface UserRepository
 * @package namespace pizzaexpress\Repositories;
 */
interface UserRepository extends RepositoryInterface
{
    public function updateDeviceToken($id,$deviceToken);
}
