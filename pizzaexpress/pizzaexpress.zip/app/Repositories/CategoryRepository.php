<?php

namespace pizzaexpress\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface CategoryRepository
 * @package namespace pizzaexpress\Repositories;
 */
interface CategoryRepository extends RepositoryInterface
{
    //
}
